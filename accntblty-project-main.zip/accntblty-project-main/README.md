# ATA-Learn-And-Be-Curious-Project

Follow the instructions in the course for completing the group LBC project.
